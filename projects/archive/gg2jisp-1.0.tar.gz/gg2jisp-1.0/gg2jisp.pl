#!/usr/bin/perl

#    gg2jisp - converts iconsets from Gadu-Gadu to Jabber clients
#    Copyright (C) 2004 Maciej Grela <thermal@poczta.onet.pl>

#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

$GG2JISP_VERSION="1.0";
$HOMEPAGE="http://gg2jisp.jabberstudio.org";

use XML::Writer;

my $w = new XML::Writer((DATA_INDENT,"1",DATA_MODE,"1"));

###

# Parse commandline arguments
use Getopt::Long;
use Getopt::Std;

sub usage {
print <STDERR>,"Usage: gg2jisp [options]\n";
print <STDERR>,"Avalible options:\n\n";
print <STDERR>,"--charset-conv=from,to			- perform character set\n";
print <STDERR>,"					conversion on input data\n";
print <STDERR>,"--meta-info=name,value;name,value...	- set iconset meta-data\n";
print <STDERR>,"					(see latest JEP-0038)\n";
print <STDERR>,"-h					- print this help\n";
print <STDERR>,"--help\n";
print <STDERR>,"-V					- print version\n";
print <STDERR>,"--version\n";
}

GetOptions( "--help" => \$long_help,
	    "--version" => \$long_version,
	    "--charset-conv=s" => \$long_cset_conv,
	    "--meta-info=s" => \$long_meta_info);
	    
getopts("Vh",\%args);

if (defined $args{h}) { $long_help="1"; }
if (defined $args{V}) { $long_version="1"; }

if (defined $long_help) {
    usage();
    exit(0);
    }

if (defined $long_version) {
    print <SDTERR>,"gg2jisp " . $GG2JISP_VERSION . "\n";
    print <STDERR>,"This is open software.\n";
    exit(0);
    }

if (defined $long_cset_conv) {
    $_=$long_cset_conv;
    
    ($long_cset_conv_from,$long_cset_conv_to) = /([^,]+),([^,]+)/;

    if (!defined $long_cset_conv_from || !defined $long_cset_conv_to) {
	print <STDERR>,"Bad character set conversion specifier: ".
	    $long_cset_conv."\n";
	exit(2);
	}

    }

# Parse meta info argument and put meta info in meta_info hash

# Default meta_info settings
%meta_info = ( "name"=>"New iconset",
	"version"=>"0.0",
	"description"=>"This iconset was created by gg2jisp v".$GG2JISP_VERSION,
	"creation"=>"00-00-0000",
	"home"=>$HOMEPAGE);

# Parse custom field list
if (defined $long_meta_info) {

    # Convert charset if option given
    if (defined $long_cset_conv) {
	from_to($long_meta_info,$long_cset_conv_from,$long_cset_conv_to);
	}

    @vpairs=split(/;+/,$long_meta_info);
    
    foreach $vpair (@vpairs) {
	$_=$vpair;
	($name,$value)= /([^,]+),(.+)/;
	if (! defined $name || ! defined $value) {
	    die "Invalid meta-info string " . $long_meta_info . "\n";
	    }
	$meta_info{$name}=$value;
	}

    }
    
####

sub put_meta {
    $w->startTag("meta");

    # Print generic fields
    foreach $name (keys(%meta_info)) {
	$w->startTag($name);
	$w->characters($meta_info{$name});
	$w->endTag($name);
    }
    
    # Put the default author (me :)
    $w->startTag("author","email" => "author`s_email", 
	"jid" => "author`s_jid");
	$w->characters("::INSERT AUTHOR NAME HERE::");
    $w->endTag("author");
    $w->endTag("meta");
}

####

use Encode("from_to");

sub put_text {

    # Convert charset if option given
    if (defined $long_cset_conv) {
	from_to($text,$long_cset_conv_from,$long_cset_conv_to);
	}

    if ( $text =~ /<.*>/ ) { $w->startTag("text","xml:lang" => "pl"); } 
    else { $w->startTag("text"); }

    $w->characters($text);
    $w->endTag("text");

    if ( $text =~ /<.*>/ ) { 
	# Write text converted to Psi :string: format
	$w->startTag("text","xml:lang" => "pl"); 
	$text =~ tr/<>/::/;
	$w->characters($text);
	$w->endTag("text");
	} 
    }

####

sub put_file {

    # Convert charset if option given
    if (defined $long_cset_conv) {
	from_to($file,$long_cset_conv_from,$long_cset_conv_to);
	}

    # Convert filename into lowcase
    $file=~ tr/[A-Z]/[a-z]/;
    
    # Detect file type by extension (add `file` in the future)
    if ($file =~ /\.png$/ ) { $w->startTag("object","mime"=>"image/png"); }
    else {
	
    if ($file =~ /\.gif$/ ) { $w->startTag("object","mime"=>"image/gif"); }
    else { $w->startTag("object"); }

    }

    $w->characters($file);
    $w->endTag("object");

#    if (defined $noanim_file) {
	# Image is animated
#	$w->startTag("x", "xmlns"=>"type");
#	$w->characters("animation");
#	$w->endTag("x");
#	}

}

####

if ( defined $long_cset_conv_to ) {
    $w->xmlDecl($long_cset_conv_to);
    } else { $w->xmlDecl(); }

$w->comment("This iconset was created by gg2jisp v".$GG2JISP_VERSION . " (C) Maciej Grela");
$w->comment("See " . $HOMEPAGE);

$w->startTag("icondef");

put_meta();

while (  $line = <STDIN> ) {

    $w->startTag("icon");
            
    # Cut the '*' at the beginning (no hidden icons)
    $line=~s/^\*//;

    if ($line =~ /^\(/ ) {

	$noanim_file=undef;
	if ($line =~ /^\((.+)\),\".+\",\".+\"/) {
	    $_=$line;
	    ($text,$file,$noanim_file) = /^\((.+)\),\"(.+)\",\"(.+)\"/;
	} else {
	    $_=$line;
	    ($text,$file) = /^\((.+)\),\"(.+)\"/;
	}
	
	@txt=split(/,+/,$text);

	# Strip "`s and print codes
	foreach $text (@txt) { $text =~ s/\"//g; put_text(); }
	    
	} else {

	$noanim_file=undef;

	if ($line =~ /^\".+\",\".+\",\".+\"/) {
	    $_=$line;
	    ($text,$file,$noanim_file) = /^\"(.+)\",\"(.+)\",\"(.+)\"/;
	} else {
	    $_=$line;
	    ($text,$file) = /^\"(.+)\",\"(.+)\"/;
	}
	
	put_text();
	}
    
    put_file();
	
    $w->endTag("icon");
    }
    
$w->endTag("icondef");
$w->end();

import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import g4p_controls.*; 
import processing.serial.*; 
import java.text.DecimalFormat; 
import java.util.List; 
import java.text.SimpleDateFormat; 
import java.util.Calendar; 
import de.voidplus.leapmotion.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class uarm_client extends PApplet {


// Need G4P library







static final  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

boolean GRAB_EN = false;
boolean SERIAL_EN = false;
boolean YZ_UPDATE = false;
boolean X_UPDATE = false;
boolean GRAB_UPDATE = false;
boolean HAND_UPDATE = false;
boolean LEAP_EN = false;

static String VERSION = "2.0";

static float LIMIT_INIT_X = 0;
static float LIMIT_MIN_X = -300;
static float LIMIT_MAX_X = 300;

static float LIMIT_MIN_Y = 50;
static float LIMIT_MAX_Y = 330;
static float LIMIT_INIT_Y = 150;

static float LIMIT_MIN_Z = -150;
static float LIMIT_MAX_Z = 250;
static float LIMIT_INIT_Z = 100;

static float LIMIT_MIN_HAND = 0;
static float LIMIT_MAX_HAND = 180;
static float LIMIT_INIT_HAND = 90;

String FIRMWARE_VERSION = "N/A";

float current_x = 0;
float current_y = 0;
float current_z = 0;
float current_h = 0;
int limit_leap_min_z = -10;
PrintWriter output;

Serial uPort;

public void settings(){
  size(1024, 500, JAVA2D);
}

public void setup(){
  output = createWriter("logs.txt"); 
  initLeapMotion();
  createGUI();
  customGUI();
  reset();
}

public void draw(){
  background(255);
  if(LEAP_EN)
   leapmotion();
  updatePos();
}

public void updatePos(){
  setCurrentPosition();
  if(GRAB_UPDATE){
    setPump();
    GRAB_UPDATE = false;
  }
  if(X_UPDATE){
    setPosition();
    X_UPDATE = false;
  }
  if(HAND_UPDATE){
    setWrist();
    HAND_UPDATE = false;
  }
  if(YZ_UPDATE){
    setPosition();
    YZ_UPDATE = false;
  }  
}

public void setCurrentPosition(){
  current_x = slider2d_xy.getValueXF();
  current_z = slider_z_axis.getValueF();
  current_y = slider2d_xy.getValueYF();
  current_h = knob_hand_axis.getValueF();
}

public void setUIValue(float x, float y, float z, float h)
{
  slider2d_xy.setValueX(x);
  slider2d_xy.setValueY(y);
  slider_z_axis.setValue(z);
  knob_hand_axis.setValue(h);
}

public void initPort(){
  String portName = droplist_serial.getSelectedText();
  printf(portName);
  try{
    uPort = new Serial(this, portName, 115200);
    printf("Connecting to Port:" + portName);
    long startTime = System.currentTimeMillis();
    delay(2000);
    while (false||(System.currentTimeMillis()-startTime)<5000) {
      while (uPort.available() > 0) {
        String line = uPort.readStringUntil('\n');
        println("line:" + line);
        if (line.startsWith("@1")) {
          SERIAL_EN = true;
          button_connect_port.setText("Disconnect");
          break;
        }
      }
      if (SERIAL_EN)
        break;
    }
    if (SERIAL_EN) {
      String msg = "#1 P203\n";
      uPort.write(msg);
      startTime = System.currentTimeMillis();
      while (false||(System.currentTimeMillis()-startTime)<5000) {
        while (uPort.available() > 0) {
          String line = uPort.readStringUntil('\n');
          if (line.startsWith("$1 OK")){
            FIRMWARE_VERSION = line.split(" ")[2];
            label_firmware_vesion_label.setText(FIRMWARE_VERSION);
            break;
          }
        }
        if (FIRMWARE_VERSION != "N/A")
          break;
      }            
      reset();
    }
    else{
      releasePort();
      G4P.showMessage(this, "Firmware Not Correct!", "ERROR", G4P.ERROR);
    }
    
  }catch(Exception e){
    G4P.showMessage(this, "Can't initialize Port" + portName + "Error: " + e, "ERROR", G4P.ERROR);
  }
  
}

public void releasePort(){
  try{
     SERIAL_EN = false;
     uPort.stop();
     button_connect_port.setText("Connect");
     label_firmware_vesion_label.setText("N/A");
  }catch(Exception e){
    G4P.showMessage(this, "Can't Disconnect Port", "ERROR", G4P.ERROR);
  }
}

public String[] getUArmPorts(){
    List<String> ports = new ArrayList<String>();
  for (String port: Serial.list()) {
    //println('\n' + port + ':');
    String idProduct = Serial.getProperties(port).get("idProduct");
    if ( !port.startsWith("/dev/cu.") && idProduct!= null && idProduct.equals("6001"))
    //if ( !port.startsWith("/dev/cu.") && idProduct!= null )
    {
      ports.add(port);
    }
  }
  String[] stockArr = new String[ports.size()];
  return ports.toArray(stockArr);
}

public void reset(){
  setUIValue(LIMIT_INIT_X,LIMIT_INIT_Y,LIMIT_INIT_Z,LIMIT_INIT_HAND);
  button_grab.setText("Catch");
  GRAB_EN = false;
  GRAB_UPDATE = true;
  YZ_UPDATE = true;
  X_UPDATE = true;
  HAND_UPDATE = true;
  GRAB_UPDATE = true;
  updatePos();
}

// Use this method to add additional statements
// to customise the GUI controls
public void customGUI(){
  slider2d_xy.setEasing(5.0f);
  droplist_serial.setItems(getUArmPorts(),0);
}

public String roundTwoDecimals(float d) {
  DecimalFormat twoDForm = new DecimalFormat("#.#");
  return twoDForm.format(d);
}

public void printf(String msg) {
  println(msg);
  msg = sdf.format(Calendar.getInstance().getTime()) + ": " + msg;
  output.println(msg);
  output.flush();
}
/* =========================================================
 * ====                   WARNING                        ===
 * =========================================================
 * The code in this tab has been generated from the GUI form
 * designer and care should be taken when editing this file.
 * Only add/edit code inside the event handlers i.e. only
 * use lines between the matching comment tags. e.g.

 void myBtnEvents(GButton button) { //_CODE_:button1:12356:
     // It is safe to enter your event code here  
 } //_CODE_:button1:12356:
 
 * Do not rename this tab!
 * =========================================================
 */

public void logo_icon_Click(GImageButton source, GEvent event) { //_CODE_:logo_icon:991812:
  //printf("logo_icon - GImageButton >> GEvent." + event + " @ " + millis());
} //_CODE_:logo_icon:991812:

public void logo_text_click(GImageButton source, GEvent event) { //_CODE_:logo_text:570005:
  //printf("logo_text - GImageButton >> GEvent." + event + " @ " + millis());
} //_CODE_:logo_text:570005:

public void slider2d_xy_changed(GSlider2D source, GEvent event) { //_CODE_:slider2d_xy:935079:
  //printf("slider2d_xy - GSlider2D >> GEvent." + event + " @ " + millis());
  val_x_axis.setText(roundTwoDecimals(slider2d_xy.getValueXF()));
  val_y_axis.setText(roundTwoDecimals(slider2d_xy.getValueYF()));
  YZ_UPDATE = true;  
  X_UPDATE = true;
} //_CODE_:slider2d_xy:935079:

public void slider_z_axis_changed(GSlider source, GEvent event) { //_CODE_:slider_z_axis:891404:
  //printf("slider_z_axis - GSlider >> GEvent." + event + " @ " + millis());
  YZ_UPDATE = true;
} //_CODE_:slider_z_axis:891404:

public void knob_hand_axis_changed(GKnob source, GEvent event) { //_CODE_:knob_hand_axis:834379:
  //printf("knob_hand_axis - GKnob >> GEvent." + event + " @ " + millis());
  val_hand_axis.setText(roundTwoDecimals(knob_hand_axis.getValueF()));
  HAND_UPDATE = true;
} //_CODE_:knob_hand_axis:834379:

public void setting_panel_clicked(GPanel source, GEvent event) { //_CODE_:setting_panel:944818:
  //printf("setting_panel - GPanel >> GEvent." + event + " @ " + millis());
} //_CODE_:setting_panel:944818:

public void connect_serial_clicked(GButton source, GEvent event) { //_CODE_:droplist_serial:920274:
  printf("droplist_serial - GDropList >> GEvent." + event + " @ " + millis());
  if (!SERIAL_EN){
    initPort();
  }
  else{
    releasePort();
  }
    
} //_CODE_:droplist_seDisconnect0274:

public void button_rescan_port_clicked(GButton source, GEvent event) { //_CODE_:button_rescan_port:922949:
  printf("button1 - GButton >> GEvent." + event + " @ " + millis());
  droplist_serial.setItems(getUArmPorts(),0);
} //_CODE_:button_rescan_port:922949:

public void cb_leapmotion_clicked(GCheckbox source, GEvent event) { //_CODE_:cb_leapmotion:469722:
  printf("cb_leapmotion - GCheckbox >> GEvent." + event + " @ " + millis());
  LEAP_EN = cb_leapmotion.isSelected();
} //_CODE_:cb_leapmotion:469722:

public void slider_min_z_changed(GSlider source, GEvent event) { //_CODE_:slider_min_z:502052:
  printf("slider_min_z - GSlider >> GEvent." + event + " @ " + millis());
  limit_leap_min_z = slider_min_z.getValueI();
} //_CODE_:slider_min_z:502052:

public void button_grab_clicked(GButton source, GEvent event) { //_CODE_:button_grab:849823:
  //printf("button_grab - GButton >> GEvent." + event + " @ " + millis());
  GRAB_UPDATE = true;
  if(!GRAB_EN){
    button_grab.setText("Release");
    GRAB_EN = true;
  } else {
    button_grab.setText("Catch");
    GRAB_EN = false;
  }
} //_CODE_:button_grab:849823:

public void button_reset_clicked(GButton source, GEvent event) { //_CODE_:button_reset:484659:
  //printf("button_reset - GButton >> GEvent." + event + " @ " + millis());
  reset();
} //_CODE_:button_reset:484659:



// Create all the GUI controls. 
// autogenerated do not edit
public void createGUI(){
  G4P.messagesEnabled(false);
  G4P.setGlobalColorScheme(GCScheme.BLUE_SCHEME);
  G4P.setCursor(ARROW);
  surface.setTitle("uArm Control Panel");
  logo_icon = new GImageButton(this, 400, 10, 114, 40, new String[] { "logo.png", "logo.png", "logo.png" } );
  GLabel label_version = new GLabel(this, 520, 20, 100, 20);
  label_version.setText("v" + VERSION);
  slider2d_xy = new GSlider2D(this, 115, 75, 520, 420);
  slider2d_xy.setLimitsX(LIMIT_INIT_X, LIMIT_MIN_X, LIMIT_MAX_X);
  slider2d_xy.setLimitsY(LIMIT_INIT_Y, LIMIT_MAX_Y, LIMIT_MIN_Y);
  slider2d_xy.setNumberFormat(G4P.INTEGER, 0);
  slider2d_xy.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  slider2d_xy.setOpaque(true);
  slider2d_xy.addEventHandler(this, "slider2d_xy_changed");
  label_x_axis = new GLabel(this, 210, 50, 50, 20);
  label_x_axis.setTextAlign(GAlign.LEFT, GAlign.MIDDLE);
  label_x_axis.setText("X AXIS: ");
  label_x_axis.setTextBold();
  label_x_axis.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  label_x_axis.setOpaque(false);
  val_x_axis = new GLabel(this, 270, 50, 50, 20);
  val_x_axis.setTextAlign(GAlign.LEFT, GAlign.MIDDLE);
  val_x_axis.setText("0");
  val_x_axis.setTextBold();
  val_x_axis.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  val_x_axis.setOpaque(false);
  label_y_axis = new GLabel(this, 400, 50, 50, 20);
  label_y_axis.setText("Y AXIS: ");
  label_y_axis.setTextBold();
  label_y_axis.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  label_y_axis.setOpaque(false);
  val_y_axis = new GLabel(this, 450, 50, 80, 20);
  val_y_axis.setText("0");
  val_y_axis.setTextBold();
  val_y_axis.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  val_y_axis.setOpaque(false);
  slider_z_axis = new GSlider(this, 110, 75, 420, 100, 15.0f);
  slider_z_axis.setShowValue(true);
  slider_z_axis.setShowLimits(true);
  slider_z_axis.setLimits(LIMIT_INIT_Z, LIMIT_MAX_Z, LIMIT_MIN_Z);
  slider_z_axis.setShowTicks(true);
  slider_z_axis.setEasing(5.0f);
  slider_z_axis.setRotation(PI/2, GControlMode.CORNER);
  slider_z_axis.setTextOrientation(G4P.ORIENT_LEFT);
  //slider_z_axis.setNumberFormat(G4P.INTEGER, 0);
  slider_z_axis.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  slider_z_axis.setOpaque(false);
  slider_z_axis.addEventHandler(this, "slider_z_axis_changed");
  label_z_axis = new GLabel(this, 15, 50, 50, 20);
  label_z_axis.setText("Z AXIS:");
  label_z_axis.setTextBold();
  label_z_axis.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  label_z_axis.setOpaque(false); 
  knob_hand_axis = new GKnob(this, 700, 75, 200, 200, 0.8f);
  knob_hand_axis.setTurnRange(180, 360);
  knob_hand_axis.setTurnMode(GKnob.CTRL_ANGULAR);
  knob_hand_axis.setShowArcOnly(true);
  knob_hand_axis.setOverArcOnly(true);
  knob_hand_axis.setIncludeOverBezel(false);
  knob_hand_axis.setShowTrack(false);
  knob_hand_axis.setLimits(LIMIT_INIT_HAND, LIMIT_MIN_HAND, LIMIT_MAX_HAND);
  knob_hand_axis.setShowTicks(true);
  //knob_hand_axis.setEasing(10.0);
  knob_hand_axis.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  knob_hand_axis.setOpaque(false);
  knob_hand_axis.addEventHandler(this, "knob_hand_axis_changed");
  label_hand_axis = new GLabel(this, 725, 50, 80, 20);
  label_hand_axis.setText("Hand AXIS:");
  label_hand_axis.setTextBold();
  label_hand_axis.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  label_hand_axis.setOpaque(false);
  val_hand_axis = new GLabel(this, 810, 50, 50, 20);
  val_hand_axis.setTextAlign(GAlign.LEFT, GAlign.MIDDLE);
  val_hand_axis.setText("0");
  val_hand_axis.setTextBold();
  val_hand_axis.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  val_hand_axis.setOpaque(false);
  setting_panel = new GPanel(this, 650, 280, 350, 210, "Setting");
  setting_panel.setCollapsible(false);
  setting_panel.setDraggable(false);
  setting_panel.setText("Setting");
  setting_panel.setTextBold();
  setting_panel.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  setting_panel.setOpaque(true);
  setting_panel.addEventHandler(this, "setting_panel_clicked");
  droplist_serial = new GDropList(this, 10, 25, 180, 80, 3);
  droplist_serial.setItems(loadStrings("list_920274"), 0);
  droplist_serial.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  //droplist_serial.addEventHandler(this, "droplist_serial_clicked");

  button_rescan_port = new GButton(this, 270, 25, 70, 20);
  button_rescan_port.setText("Rescan");
  button_rescan_port.setTextBold();
  button_rescan_port.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  button_rescan_port.addEventHandler(this, "button_rescan_port_clicked");
  
  button_connect_port = new GButton(this, 200, 25, 70, 20);
  button_connect_port.setText("Connect");
  button_connect_port.setTextBold();
  button_connect_port.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  button_connect_port.addEventHandler(this, "connect_serial_clicked"); 
  
  GLabel label_firmware_vesion = new GLabel(this, 10, 55, 120, 29);
  label_firmware_vesion.setText("Firmware Version:");
  
  label_firmware_vesion.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  label_firmware_vesion.setOpaque(false);
  label_firmware_vesion_label = new GLabel(this, 140, 55, 200, 29);
  label_firmware_vesion_label.setText("N/A");
  label_firmware_vesion_label.setTextBold();
  label_firmware_vesion_label.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  label_firmware_vesion_label.setOpaque(false);
  label_firmware_vesion_label.setTextBold();
  cb_leapmotion = new GCheckbox(this, 10, 110, 200, 20);
  cb_leapmotion.setTextAlign(GAlign.LEFT, GAlign.MIDDLE);
  cb_leapmotion.setText("Enable Leap Motion Control");
  cb_leapmotion.setTextBold();
  cb_leapmotion.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  cb_leapmotion.setOpaque(false);
  cb_leapmotion.addEventHandler(this, "cb_leapmotion_clicked");
  slider_min_z = new GSlider(this, 10, 140, 200, 50, 10.0f);
  slider_min_z.setShowValue(true);
  slider_min_z.setShowLimits(true);
  slider_min_z.setLimits(LIMIT_INIT_Z, LIMIT_MIN_Z, LIMIT_MAX_Z);
  slider_min_z.setShowTicks(true);
  //slider_min_z.setEasing(10.0);
  slider_min_z.setNumberFormat(G4P.INTEGER, 0);
  slider_min_z.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  slider_min_z.setOpaque(false);
  slider_min_z.addEventHandler(this, "slider_min_z_changed");
  label_leap_min_z = new GLabel(this, 215, 150, 80, 29);
  label_leap_min_z.setText("Minmum Z");
  label_leap_min_z.setTextBold();
  label_leap_min_z.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  label_leap_min_z.setOpaque(false);
  setting_panel.addControl(droplist_serial);
  setting_panel.addControl(button_rescan_port);
  setting_panel.addControl(button_connect_port);
  setting_panel.addControl(label_firmware_vesion);
  setting_panel.addControl(label_firmware_vesion_label);
  setting_panel.addControl(cb_leapmotion);
  setting_panel.addControl(slider_min_z);
  setting_panel.addControl(label_leap_min_z);
  button_grab = new GButton(this, 740, 210, 120, 40);
  button_grab.setText("Catch");
  button_grab.setTextBold();
  button_grab.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  button_grab.addEventHandler(this, "button_grab_clicked");
  button_reset = new GButton(this, 930, 10, 50, 30);
  button_reset.setText("RESET");
  button_reset.setTextBold();
  button_reset.setLocalColorScheme(GCScheme.CYAN_SCHEME);
  button_reset.addEventHandler(this, "button_reset_clicked");
}

GImageButton logo_icon; 
GImageButton logo_text;
GSlider2D slider2d_xy;
GLabel label_y_axis; 
GLabel val_x_axis; 
GLabel label_z_axis; 
GLabel val_y_axis; 
GSlider slider_z_axis; 
GLabel label_x_axis; 
GKnob knob_hand_axis;;
GLabel label_hand_axis; 
GLabel val_hand_axis; 
GPanel setting_panel; 
GDropList droplist_serial; 
GButton button_rescan_port; 
GButton button_connect_port; 
GCheckbox cb_leapmotion; 
GSlider slider_min_z; 
GLabel label_leap_min_z; 
GButton button_grab; 
GButton button_reset; 
GLabel label_firmware_vesion_label;


LeapMotion leap;

public void initLeapMotion() {
  //size(800, 500, OPENGL);
 
  // ...

  leap = new LeapMotion(this);
}

public void leapmotion() {
  background(255);
  // ...
  int fps = leap.getFrameRate();


  // ========= HANDS =========

  //for (Hand hand : leap.getHands ()) {
  if(!leap.getHands ().isEmpty())
  {
    Hand hand = (Hand) leap.getHands().toArray()[0];
    // ----- BASICS -----

    int     hand_id          = hand.getId();
    PVector hand_position    = hand.getPosition();
    // println("hand_position x:" + hand_position.x);
    // println("hand_position y:" + hand_position.y);
    // println("hand_position z:" + hand_position.z);
    PVector hand_stabilized  = hand.getStabilizedPosition();
    PVector hand_direction   = hand.getDirection();
    PVector hand_dynamics    = hand.getDynamics();
        
    float   hand_roll        = hand.getRoll();
    float   hand_pitch       = hand.getPitch();
    float   hand_yaw         = hand.getYaw();
    boolean hand_is_left     = hand.isLeft();
    boolean hand_is_right    = hand.isRight();
    float   hand_grab        = hand.getGrabStrength();
    float   hand_pinch       = hand.getPinchStrength();
    float   hand_time        = hand.getTimeVisible();
    PVector sphere_position  = hand.getSpherePosition();
    float   sphere_radius    = hand.getSphereRadius();
    
    println(hand_dynamics);
    println(hand_grab);


    // ----- SPECIFIC FINGER -----

    Finger  finger_thumb     = hand.getThumb();
    // or                      hand.getFinger("thumb");
    // or                      hand.getFinger(0);

    Finger  finger_index     = hand.getIndexFinger();
    // or                      hand.getFinger("index");
    // or                      hand.getFinger(1);

    Finger  finger_middle    = hand.getMiddleFinger();
    // or                      hand.getFinger("middle");
    // or                      hand.getFinger(2);

    Finger  finger_ring      = hand.getRingFinger();
    // or                      hand.getFinger("ring");
    // or                      hand.getFinger(3);

    Finger  finger_pink      = hand.getPinkyFinger();
    // or                      hand.getFinger("pinky");
    // or                      hand.getFinger(4);        


    // ----- DRAWING -----

    hand.draw(8.0f);
    tint(255, 200);
    // hand.drawSphere();
     int xP = (int)map(constrain(hand_stabilized.x,     0, 1000),   0, 1000, -300,   300);  // min: -90   max: 90
     int zP = (int)map(constrain(hand_stabilized.y,     50,  250), 150,  250, 250,  limit_leap_min_z);  //Z axis
     int yP = (int)map(constrain(hand_position.z,       0,   80),   0,   80,   50,  330);  // min: 0     max: 210 // Y axis
     //int rP = (int)map(constrain(hand_yaw - xP * 0.5, -40,   40), -40,   40, 0,   180);
     //println("hand_stabilized.x = " + hand_stabilized.x);
     setUIValue(xP,yP,zP,90);
      if(hand_grab >= 0.8f && GRAB_EN == false)
      {
        GRAB_EN = true;
        GRAB_UPDATE = true;
      }
      else if(hand_grab < 0.8f && GRAB_EN == true)
      {
        GRAB_EN = false;
        GRAB_UPDATE = true;
      }
       
    // ========= ARM =========

    if (hand.hasArm()) {
      Arm     arm               = hand.getArm();
      float   arm_width         = arm.getWidth();
      PVector arm_wrist_pos     = arm.getWristPosition();
      PVector arm_elbow_pos     = arm.getElbowPosition();
    }


    // ========= FINGERS =========

    for (Finger finger : hand.getFingers()) {
      // Alternatives:
      // hand.getOutstrechtedFingers();
      // hand.getOutstrechtedFingersByAngle();

      // ----- BASICS -----

      int     finger_id         = finger.getId();
      PVector finger_position   = finger.getPosition();
      PVector finger_stabilized = finger.getStabilizedPosition();
      PVector finger_velocity   = finger.getVelocity();
      PVector finger_direction  = finger.getDirection();
      float   finger_time       = finger.getTimeVisible();


      // ----- SPECIFIC FINGER -----

      switch(finger.getType()) {
      case 0:
        // System.out.println("thumb");
        break;
      case 1:
        // System.out.println("index");
        break;
      case 2:
        // System.out.println("middle");
        break;
      case 3:
        // System.out.println("ring");
        break;
      case 4:
        // System.out.println("pinky");
        break;
      }


      // ----- SPECIFIC BONE -----

      Bone    bone_distal       = finger.getDistalBone();
      // or                       finger.get("distal");
      // or                       finger.getBone(0);

      Bone    bone_intermediate = finger.getIntermediateBone();
      // or                       finger.get("intermediate");
      // or                       finger.getBone(1);

      Bone    bone_proximal     = finger.getProximalBone();
      // or                       finger.get("proximal");
      // or                       finger.getBone(2);

      Bone    bone_metacarpal   = finger.getMetacarpalBone();
      // or                       finger.get("metacarpal");
      // or                       finger.getBone(3);


      // ----- DRAWING -----

      // finger.draw(); // = drawLines()+drawJoints()
      // finger.drawLines();
      // finger.drawJoints();


      // ----- TOUCH EMULATION -----

      int     touch_zone        = finger.getTouchZone();
      float   touch_distance    = finger.getTouchDistance();

      switch(touch_zone) {
      case -1: // None
        break;
      case 0: // Hovering
        // println("Hovering (#"+finger_id+"): "+touch_distance);
        break;
      case 1: // Touching
        // println("Touching (#"+finger_id+")");
        break;
      }
    }


    // ========= TOOLS =========

    for (Tool tool : hand.getTools ()) {


      // ----- BASICS -----

      int     tool_id           = tool.getId();
      PVector tool_position     = tool.getPosition();
      PVector tool_stabilized   = tool.getStabilizedPosition();
      PVector tool_velocity     = tool.getVelocity();
      PVector tool_direction    = tool.getDirection();
      float   tool_time         = tool.getTimeVisible();


      // ----- DRAWING -----

      // tool.draw();


      // ----- TOUCH EMULATION -----

      int     touch_zone        = tool.getTouchZone();
      float   touch_distance    = tool.getTouchDistance();

      switch(touch_zone) {
      case -1: // None
        break;
      case 0: // Hovering
        // println("Hovering (#"+tool_id+"): "+touch_distance);
        break;
      case 1: // Touching
        // println("Touching (#"+tool_id+")");
        break;
      }
    }
  }


  // ========= DEVICES =========

  for (Device device : leap.getDevices ()) {
    float device_horizontal_view_angle = device.getHorizontalViewAngle();
    float device_verical_view_angle = device.getVerticalViewAngle();
    float device_range = device.getRange();
  }
}

// ========= CALLBACKS =========

public void leapOnInit() {
  // println("Leap Motion Init");
}
public void leapOnConnect() {
  // println("Leap Motion Connect");
}
public void leapOnFrame() {
  // println("Leap Motion Frame");
}
public void leapOnDisconnect() {
  // println("Leap Motion Disconnect");
}
public void leapOnExit() {
  // println("Leap Motion Exit");
}

public void setPosition(){
    String msg = "#1 G0 X" + roundTwoDecimals(current_x) + " Y" + roundTwoDecimals(current_y) + " Z" + roundTwoDecimals(current_z) + " F0\n";
    printf(msg);
   if(SERIAL_EN)
     uPort.write(msg);  
}

public void setPump(){
    int pump_status = 0;
    if (GRAB_EN)
      pump_status = 1;
    else
      pump_status = 0;
    String msg_pump = "#1 M231 V"+ pump_status + "\n";
    String msg_gripper = "#1 M232 V"+ pump_status + "\n";
    printf(msg_pump);
    printf(msg_gripper);
   if(SERIAL_EN){
     uPort.write(msg_pump);
     uPort.write(msg_gripper);
   }
}

public void setWrist(){
    String msg = "#1 G202 N3 V" + current_h + "\n";
    printf(msg);
   if(SERIAL_EN)
     uPort.write(msg);    
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "uarm_client" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
